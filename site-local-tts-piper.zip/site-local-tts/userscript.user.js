// ==UserScript==
// @name         Site Local TTS — eSpeak + Piper
// @namespace    local.site.tts
// @version      1.1.0
// @description  Adds inline eSpeak and Piper neural TTS buttons to readable page content.
// @match        http://*/*
// @match        https://*/*
// @grant        GM_xmlhttpRequest
// @connect      127.0.0.1
// @run-at       document-idle
// ==/UserScript==

(() => {
  "use strict";

  if (window.__SITE_LOCAL_TTS_USER__) return;
  window.__SITE_LOCAL_TTS_USER__ = true;

  const BASE = "http://127.0.0.1:8765/tts";
  const SELECTORS = [
    '[data-message-author-role="assistant"]',
    '[data-role="assistant"]',
    '[class*="assistant"][class*="message"]',
    '.ds-markdown',
    'article',
    '[role="article"]',
    'main [class*="markdown"]',
    'main [class*="message"]'
  ];

  let currentAudio = null;
  let currentButton = null;

  const cleanText = el => {
    const clone = el.cloneNode(true);
    clone.querySelectorAll(".site-local-tts-controls").forEach(x => x.remove());
    return String(clone.innerText || "").replace(/\s+/g, " ").trim();
  };

  const visible = el => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 80 && r.height > 20 &&
      s.display !== "none" && s.visibility !== "hidden";
  };

  const stop = () => {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.src = "";
      currentAudio = null;
    }
    if (currentButton) currentButton.textContent = currentButton.dataset.icon;
    currentButton = null;
  };

  const requestAudio = (text, engine) => new Promise((resolve, reject) => {
    const url = `${BASE}?engine=${encodeURIComponent(engine)}`;

    if (typeof GM_xmlhttpRequest === "function") {
      GM_xmlhttpRequest({
        method: "POST",
        url,
        headers: {"Content-Type": "text/plain;charset=UTF-8"},
        data: text,
        responseType: "blob",
        onload: r => {
          if (r.status >= 200 && r.status < 300) resolve(r.response);
          else reject(new Error(
            typeof r.responseText === "string" && r.responseText
              ? r.responseText
              : `TTS HTTP ${r.status}`
          ));
        },
        onerror: () => reject(new Error("Local TTS request failed"))
      });
      return;
    }

    const opts = {
      method: "POST",
      mode: "cors",
      body: text,
      headers: {"Content-Type": "text/plain;charset=UTF-8"}
    };
    try { opts.targetAddressSpace = "loopback"; } catch {}

    fetch(new Request(url, opts))
      .then(async r => {
        if (!r.ok) throw new Error(await r.text() || `TTS HTTP ${r.status}`);
        return r.blob();
      })
      .then(resolve, reject);
  });

  const speak = async (el, button, engine) => {
    if (currentButton === button && currentAudio) {
      stop();
      return;
    }

    stop();
    button.textContent = "⏳";
    currentButton = button;

    try {
      const blob = await requestAudio(cleanText(el), engine);
      const url = URL.createObjectURL(blob);
      currentAudio = new Audio(url);

      currentAudio.onended = () => {
        URL.revokeObjectURL(url);
        stop();
      };

      currentAudio.onerror = () => {
        URL.revokeObjectURL(url);
        button.textContent = "❌";
        currentAudio = null;
        currentButton = null;
      };

      button.textContent = "⏹";
      await currentAudio.play();
    } catch (error) {
      console.error(`[Site Local TTS:${engine}]`, error);
      button.textContent = "❌";
      button.title = String(error).trim();
      currentAudio = null;
      currentButton = null;
    }
  };

  const candidates = () => {
    const seen = new Set();
    const out = [];

    for (const selector of SELECTORS) {
      document.querySelectorAll(selector).forEach(el => {
        if (seen.has(el) || !visible(el) || cleanText(el).length < 40) return;
        seen.add(el);
        out.push(el);
      });
    }

    if (!out.length) {
      const root = document.querySelector("main") || document.body;
      root.querySelectorAll("section,div").forEach(el => {
        if (!visible(el)) return;
        const text = cleanText(el);
        if (text.length < 120 || text.length > 20000) return;
        const substantialChildren = [...el.children]
          .filter(c => String(c.innerText || "").trim().length > 100).length;
        if (substantialChildren <= 3) out.push(el);
      });
    }

    return out;
  };

  const makeButton = (icon, label, engine, el) => {
    const b = document.createElement("button");
    b.textContent = icon;
    b.dataset.icon = icon;
    b.title = label;
    b.style.cssText =
      "margin:0 3px;padding:2px 7px;border:1px solid #7776;border-radius:6px;" +
      "background:transparent;color:inherit;cursor:pointer;font:14px system-ui;" +
      "line-height:1.4;vertical-align:middle";

    b.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      speak(el, b, engine);
    });

    return b;
  };

  const addButtons = () => {
    candidates().forEach(el => {
      if (el.querySelector(":scope > .site-local-tts-controls")) return;

      const controls = document.createElement("span");
      controls.className = "site-local-tts-controls";
      controls.style.cssText =
        "display:inline-flex;align-items:center;gap:2px;margin:4px 6px 4px 0";

      controls.append(
        makeButton("🔊", "Read with eSpeak NG", "espeak", el),
        makeButton("🎙️", "Read with Piper neural voice", "piper", el)
      );

      el.prepend(controls);
    });
  };

  addButtons();
  new MutationObserver(addButtons)
    .observe(document.body, {childList: true, subtree: true});
})();
